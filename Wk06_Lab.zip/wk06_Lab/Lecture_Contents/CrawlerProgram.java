package wk06_Lab.Lecture_Contents;

interface Searchable {
    public void search(String s);
}

abstract class Crawler implements Searchable {
    private String baseUrl;

    public void setBaseUrl(String url) {
        baseUrl = url;
    }

    public abstract void crawl();
}

class TwitterCrawler extends Crawler {
    public void crawl() {
        System.out.println("Crawl tweets!");
    }

    public void search(String s) {
        System.out.println("Search tweets: " + s);

    }
}

class RedditCrawler extends Crawler {
    public void crawl() {
        System.out.println("Crawl posts!");
    }

    public void search(String s) {
        System.out.println("Search posts: " + s);
    }
}

class StorageHandler implements Searchable {
    public void search(String s) {
        System.out.println("Search files: " + s);
    }
}

public class CrawlerProgram {
    public void crawl(Crawler crawler) {
        crawler.crawl();
    }

    public void search(Searchable searcher, String s) {
        searcher.search(s);
    }

    public static void main(String args[]) {
        CrawlerProgram crawlerProgram = new CrawlerProgram();
        Crawler twitterCrawler = new TwitterCrawler(); // class TwitterCrawler extends Crawler
        Crawler redditCrawler = new RedditCrawler();  // class RedditCrawler extends Crawler
        crawlerProgram.crawl(twitterCrawler);
        crawlerProgram.search(twitterCrawler, "1");
        crawlerProgram.crawl(redditCrawler);
        crawlerProgram.search(redditCrawler, "2");
        crawlerProgram.search(new StorageHandler(), "3"); // class StorageHandler implements Searchable
    }
}